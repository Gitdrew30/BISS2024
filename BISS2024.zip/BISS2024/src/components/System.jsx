export default function System() {
  return (
    <div className=" min-h-screen bg-slate-900">
      <h1 className=" text-center py-72 text-4xl text-cyan-200 animate-pulse">
      🤖 Still Working.....
      </h1>
    </div>
  );
}
