import {
    Page
} from '../../lib';

export default function ResidentProfile() {
    return(
        <Page id='residentProfile' title='Resident Profile Information' fullscreen={true}>
            <b>NOTHING TO SEE</b>
        </Page>
    );
}